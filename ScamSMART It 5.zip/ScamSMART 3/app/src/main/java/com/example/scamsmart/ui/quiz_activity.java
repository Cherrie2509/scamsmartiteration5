package com.example.scamsmart.ui;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.Image;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.scamsmart.R;
import com.example.scamsmart.models.Question;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class quiz_activity extends AppCompatActivity {


    //code changed from this example https://www.geeksforgeeks.org/how-to-create-a-quiz-app-in-android/


    ImageView imQuestion;
    Button btnTrust;
    Button btnDont;
    Button btnStart;
    TextView tvWelcome;
    TextView tvThanks;
    Button btnBack;
    Button btnViewIncorrect;
    int questionCounter;
    int correctCounter;
    List<Question> questionList = new ArrayList<Question>();
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    FirebaseAuth auth;
    String username;



    //Declaring questions to be asked
    public Question[] questionBank = new Question[] {
            new Question("https://i.imgur.com/0zqb3Cq.png", "Don't Trust", "Text", "You shouldn't trust this because xyz"),
            new Question("https://i.imgur.com/3KaDlz8.jpg", "Trust", "Text", "You can trust this because xyz. But always be cautious!")

    };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_activity);

        questionCounter = 0;

        imQuestion = findViewById(R.id.imQuestion);
        btnTrust = findViewById(R.id.btnTrust);
        btnDont = findViewById(R.id.btnDontTrust);
        btnStart = findViewById(R.id.btnStartQuiz);
        tvWelcome = findViewById(R.id.tvWelcome);
        tvThanks = findViewById(R.id.tvThanks);
        btnBack = findViewById(R.id.btnBackToMenu);
        btnViewIncorrect= findViewById(R.id.btnViewIncorrect);

        setTitle("ScamSMART - Quiz");





        auth = FirebaseAuth.getInstance();
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String userID = auth.getCurrentUser().getUid();
        Log.d("USERIDCHECK",userID);

        //Retrieving the user from cloud firestore now that we have the ID
        //https://firebase.google.com/docs/firestore/query-data/get-data
        DocumentReference documentReference = db.collection("Users").document(userID);
        documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                        String temp = String.valueOf(document.getData().get("Name"));
                        setUsername(temp);


                    } else {
                        Log.d("TAG", "No such document");
                    }
                } else {
                    Log.d("TAG", "get failed with ", task.getException());
                }
            }
        });
















        //Setting buttons to be invisible before the quiz is started
        btnTrust.setVisibility(View.INVISIBLE);
        btnDont.setVisibility(View.INVISIBLE);
        tvThanks.setVisibility(View.INVISIBLE);
        btnBack.setVisibility(View.INVISIBLE);
        btnViewIncorrect.setVisibility(View.INVISIBLE);


        //The two answer options
        btnTrust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkQuestions("Trust");
            }
        });

        btnDont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkQuestions("Don't Trust");
            }
        });



        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startQuiz();
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(quiz_activity.this, MainActivity.class);
                startActivity(intent);

            }
        });

        btnViewIncorrect.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(quiz_activity.this, incorrectanswers_activity.class);
                Bundle args = new Bundle();
                args.putSerializable("ARRAYLIST",(Serializable)questionList);
                intent.putExtra("BUNDLE",args);
                startActivity(intent);
            }
        });


    }

    private void setUsername(String temp) {
        username = temp;
    }

    //Checks if the answer submitted is corrected, and displays the next question, and displays results at the end
    public void checkQuestions(String string) {
        if(string.equals(questionBank[questionCounter].getAnswer())  ) {
            correctCounter +=1;

            if(questionCounter < questionBank.length -1 ) {
                questionCounter += 1;
                Glide.with(this).load(questionBank[questionCounter].getImageurl()).into(imQuestion);
            }
            else {
                btnTrust.setVisibility(View.INVISIBLE);
                btnDont.setVisibility(View.INVISIBLE);
                imQuestion.setVisibility(View.INVISIBLE);
                tvThanks.setText("Thank you, you scored " + correctCounter + " out of " + questionBank.length);
                int result = (int) ((Double.parseDouble(String.valueOf(correctCounter)) / Double.parseDouble(String.valueOf(questionBank.length))) * 100);

                Log.d("Check Result1",correctCounter + "");
                Log.d("Check Result2",questionBank.length + "");
                Log.d("Check Result3",result + "");
                tvThanks.setVisibility(View.VISIBLE);
                btnBack.setVisibility(View.VISIBLE);
                btnViewIncorrect.setVisibility(View.VISIBLE);
                if(result == 100) {
                    btnViewIncorrect.setVisibility(View.INVISIBLE);
                }


                Map<String, Object> data = new HashMap<>();
                data.put("username", username);
                data.put("Result", result);
                //Using a timestamp allows sorting the posts by when they are posted in the recycler view (recent_firebase_activity)
                //Adapted from https://medium.com/firebase-developers/the-secrets-of-firestore-fieldvalue-servertimestamp-revealed-29dd7a38a82b
                data.put("Timestamp", FieldValue.serverTimestamp());


                //Sending the post to the firebase DB
                db.collection("QuizResults")
                        .add(data)
                        .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {
                                Log.d("TAG", "DocumentSnapshot written with ID: " + documentReference.getId());
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.w("TAG", "Error adding document", e);
                                Toast.makeText(quiz_activity.this, "Failed", Toast.LENGTH_SHORT).show();
                            }
                        });



            }
        }
        else {

            questionList.add(questionBank[questionCounter]);

            if(questionCounter <  questionBank.length -1) {
                questionCounter += 1;
                Glide.with(this).load(questionBank[questionCounter].getImageurl()).into(imQuestion);
            }
            else {
                btnTrust.setVisibility(View.INVISIBLE);
                btnDont.setVisibility(View.INVISIBLE);
                imQuestion.setVisibility(View.INVISIBLE);
                tvThanks.setText("Thank you, you scored " + correctCounter + " out of " + questionBank.length);
                int result = (int) ((Double.parseDouble(String.valueOf(correctCounter)) / Double.parseDouble(String.valueOf(questionBank.length))) * 100);
                Log.d("Check Result1",correctCounter + "");
                Log.d("Check Result2",questionBank.length + "");
                Log.d("Check Result3",result + "");
                tvThanks.setVisibility(View.VISIBLE);
                btnBack.setVisibility(View.VISIBLE);
                btnViewIncorrect.setVisibility(View.VISIBLE);



                Map<String, Object> data = new HashMap<>();
                data.put("username", username);
                data.put("Result", result);
                //Using a timestamp allows sorting the posts by when they are posted in the recycler view (recent_firebase_activity)
                //Adapted from https://medium.com/firebase-developers/the-secrets-of-firestore-fieldvalue-servertimestamp-revealed-29dd7a38a82b
                data.put("Timestamp", FieldValue.serverTimestamp());


                //Sending the post to the firebase DB
                db.collection("QuizResults")
                        .add(data)
                        .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {
                                Log.d("TAG", "DocumentSnapshot written with ID: " + documentReference.getId());
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.w("TAG", "Error adding document", e);
                                Toast.makeText(quiz_activity.this, "Failed", Toast.LENGTH_SHORT).show();
                            }
                        });









            }
        }
    }

    //Setting some controls visible once the quiz is started
    public void startQuiz() {
        btnStart.setVisibility(View.INVISIBLE);
        btnTrust.setVisibility(View.VISIBLE);
        btnDont.setVisibility(View.VISIBLE);
        tvWelcome.setVisibility(View.INVISIBLE);
        Glide.with(this).load(questionBank[questionCounter].getImageurl()).into(imQuestion);
    }



    }






