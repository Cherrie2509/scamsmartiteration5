package com.example.scamsmart.adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.scamsmart.R;
import com.example.scamsmart.models.Post;
import com.example.scamsmart.ui.block_activity;
import com.example.scamsmart.ui.recent_firebase_activity;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

import org.jetbrains.annotations.NotNull;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PostAdapter extends FirestoreRecyclerAdapter<Post, PostAdapter.PostHolder> {

    //This is a FireStore Recycler adapter utilising the Firebase UI library
    //Adapted from https://medium.com/quick-code/display-data-from-firebase-firestore-in-android-recyclerview-db39f8c7d6b

    Context context;
    String userType;
    Date date1;

    /**
     * Create a new RecyclerView adapter that listens to a Firestore Query.  See {@link
     * FirestoreRecyclerOptions} for configuration options.
     *
     * @param options
     */
    public PostAdapter(@NonNull @NotNull FirestoreRecyclerOptions<Post> options, Context context, String usertype) {
        super(options);
        this.context = context;
        userType = usertype;
    }

    @Override
    protected void onBindViewHolder(@NonNull @NotNull PostAdapter.PostHolder holder, int position, @NonNull @NotNull Post model) {

        Log.d("USERINADAPTERBEFORE",userType);
        if(userType.equals("admin")) {
            Log.d("USERINADAPTER",userType);
            holder.btnBlock.setText("Delete");
        }



        SimpleDateFormat sfd = new SimpleDateFormat("dd-MM-yyyy HH:mm");
        //sfd.format(model.getTimestamp());

        holder.tvUsername.setText("Posted By: " + model.getUsername());
        holder.tvTimestamp.setText(sfd.format(model.getTimestamp()));
        holder.tvNumber.setText(model.getNumber());
        holder.etDescription.setText(model.getDescription());
        holder.btnBlock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(userType.equals("admin")) {

                    DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            switch (which){
                                case DialogInterface.BUTTON_POSITIVE:
                                    //Code for deleting
                                    Log.d("POSITIONTEST",position + "");
                                    deleteItem(position);
                                    break;

                                case DialogInterface.BUTTON_NEGATIVE:
                                    //No button clicked
                                    break;
                            }
                        }
                    };

                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    builder.setMessage("Are you sure you want to delete?").setNegativeButton("No", dialogClickListener).setPositiveButton("Yes", dialogClickListener)
                            .show();



                }

                else  {
                //This passes the number to the blocking activity
                Intent intent = new Intent(context, block_activity.class);
                intent.putExtra("Number", model.getNumber());


                context.startActivity(intent);
                }
            }
        });
    }

    //Reference here
    public void deleteItem(int position){
        getSnapshots().getSnapshot(position).getReference().delete();
    }

    @NonNull
    @NotNull
    @Override
    public PostHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row,parent,false);
        return new PostHolder(v);
    }

    class PostHolder extends RecyclerView.ViewHolder  {
        TextView tvUsername;
        TextView tvNumber;
        TextView tvTimestamp;
        Button btnBlock;
        EditText etDescription;
        ConstraintLayout parentLayout;

        public PostHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            tvUsername = itemView.findViewById(R.id.tvUser);
            tvNumber = itemView.findViewById(R.id.tvNumber);
            btnBlock = itemView.findViewById(R.id.btnBlock);
            etDescription = itemView.findViewById(R.id.etDesc);
            tvTimestamp = itemView.findViewById(R.id.tvTimestamp);
            parentLayout = itemView.findViewById(R.id.row);
        }
    }

}
