package com.example.scamsmart.models;

public class User {

    //Not currently used
     private Long userid;
     private String name;



    public Long getUserid() {
        return userid;
    }

    public void setUserid(Long userid) {
        this.userid = userid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
