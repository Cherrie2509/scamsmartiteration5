package com.example.scamsmart.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.scamsmart.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class report_activity extends AppCompatActivity {


    //Allows a user to report a scam number

    private static final String TAG = "TAGGGGGG";
    String Number;
    String Description;
    String username;
    String tempuser;
    String county;
    FirebaseAuth auth;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_activity);

        Button btnReportNumber = findViewById(R.id.btnReportNumber);
        Button btnViewRecent = findViewById(R.id.btnViewtoReport);
        EditText etScamNumber = findViewById(R.id.etScamNumber);
        EditText etDescription = findViewById(R.id.etDescription);
        btnReportNumber.setEnabled(false);
        btnViewRecent.setEnabled(false);

        setTitle("ScamSMART - Report & Post");

        //Check if a number is being passed, if it is, set it to the edittext
        if(getIntent().hasExtra("Number")){
            String text = getIntent().getExtras().getString("Number");
            etScamNumber.setText(text);
        }

        //Get the ID of the current user with firebase auth, this allows me to match it to a user in the Firestore
        //which allows a username to be attached to a post
        //https://firebase.google.com/docs/auth/android/manage-users
        auth = FirebaseAuth.getInstance();
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String email = user.getEmail();
        String userID = auth.getCurrentUser().getUid();
        Log.d("USERIDCHECK",userID);

        //Retrieving the user from cloud firestore now that we have the ID
        //https://firebase.google.com/docs/firestore/query-data/get-data
        DocumentReference documentReference = db.collection("Users").document(userID);
        documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Log.d(TAG, "DocumentSnapshot data: " + document.getData());
                        String temp = String.valueOf(document.getData().get("Name"));
                        String temp2 = String.valueOf(document.getData().get("Province"));
                        setUsername(temp, temp2);
                        btnReportNumber.setEnabled(true);
                        btnViewRecent.setEnabled(true);


                    } else {
                        Log.d(TAG, "No such document");
                    }
                } else {
                    Log.d(TAG, "get failed with ", task.getException());
                }
            }
        });



        btnViewRecent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(report_activity.this,callLog_activity.class);
                intent.putExtra("Extra","Report");
                startActivity(intent);
            }
        });


        //Calling the posts activity and passing the details over
        //https://firebase.google.com/docs/firestore/manage-data/add-data
        btnReportNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Number = etScamNumber.getText().toString();
                username = tempuser;
                Description = etDescription.getText().toString();

                Map<String, Object> data = new HashMap<>();
                data.put("description", Description);
                data.put("username", username);
                data.put("number", Number);
                //Using a timestamp allows sorting the posts by when they are posted in the recycler view (recent_firebase_activity)
                //Adapted from https://medium.com/firebase-developers/the-secrets-of-firestore-fieldvalue-servertimestamp-revealed-29dd7a38a82b
                data.put("timestamp", FieldValue.serverTimestamp());
                data.put("Province",county);


                //Sending the post to the firebase DB
                db.collection("Posts")
                        .add(data)
                        .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {
                                Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.getId());
                                Intent startintent = new Intent(report_activity.this,recent_firebase_activity.class);
                                startActivity(startintent);
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.w(TAG, "Error adding document", e);
                                Toast.makeText(report_activity.this, "Failed", Toast.LENGTH_SHORT).show();
                            }
                        });


            }
        });

    }

    private void setUsername(String temp, String temp2) {
        Log.d("USERCHECK",temp);
        tempuser = temp;
        county = temp2;

    }
}