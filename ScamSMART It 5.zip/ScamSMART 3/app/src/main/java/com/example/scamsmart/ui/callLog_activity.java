package com.example.scamsmart.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.CallLog;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.example.scamsmart.R;
import com.example.scamsmart.adapters.CallRecyclerAdapter;
import com.example.scamsmart.models.Call;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;



public class callLog_activity extends AppCompatActivity {

    //Activity that display the users call log
    //recycler view code adapted from https://www.youtube.com/watch?v=FFCpjZkqfb0
    RecyclerView rvCallList;
    RecyclerView.Adapter rvAdapter;
    RecyclerView.LayoutManager layoutManager;
    List<Call> callList = new ArrayList<Call>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_log_activity);

        setTitle("ScamSMART - Call Log");



        //call log code adapted from https://www.youtube.com/watch?v=wj_I1pwVCq0

        if (ContextCompat.checkSelfPermission(callLog_activity.this, Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(callLog_activity.this, Manifest.permission.READ_CALL_LOG)) {

                ActivityCompat.requestPermissions(callLog_activity.this, new String [] {Manifest.permission.READ_CALL_LOG}, 1);
            } else {
                ActivityCompat.requestPermissions(callLog_activity.this, new String [] {Manifest.permission.READ_CALL_LOG}, 1);
            }
        } else {
            //Displaying recyclerview
            callList = getCallDetails();
            rvCallList = (RecyclerView)findViewById(R.id.rvCalls);
            rvCallList.setHasFixedSize(true);
            layoutManager = new LinearLayoutManager(callLog_activity.this);
            rvCallList.setLayoutManager(layoutManager);
            rvAdapter = new CallRecyclerAdapter(callList,callLog_activity.this);
            rvCallList.setAdapter(rvAdapter);

        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,  int[] grantResults) {
        switch (requestCode) {
            case 1: {
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if(ContextCompat.checkSelfPermission(callLog_activity.this, Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(this, "Permission granted", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "No permission", Toast.LENGTH_SHORT).show();
                }
                return;
            }
        }
    }


    private List<Call> getCallDetails() {

        List<Call> callList = new ArrayList<Call>();

        Cursor managedCursor = getContentResolver().query(CallLog.Calls.CONTENT_URI, null, null, null, android.provider.CallLog.Calls.DATE + " DESC", null);
        int counter = 0;
        int number = managedCursor.getColumnIndex(CallLog.Calls.NUMBER);
        int type = managedCursor.getColumnIndex(CallLog.Calls.TYPE);
        int date = managedCursor.getColumnIndex(CallLog.Calls.DATE);
        int duration = managedCursor.getColumnIndex(CallLog.Calls.DURATION);

        while (managedCursor.moveToNext()) {

            String phNumber = managedCursor.getString(number);
            String callType = managedCursor.getString(type);
            String callDate = managedCursor.getString(date);
            Date callDayTime = new Date(Long.valueOf(callDate));
            SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yy HH:mm");
            String dateString = formatter.format(callDayTime);
            String callDuration = managedCursor.getString(duration);
            String dir = null;
            int dircode = Integer.parseInt(callType);
            switch (dircode) {
                case CallLog.Calls.OUTGOING_TYPE:
                    dir = "OUTGOING";
                    break;
                case CallLog.Calls.INCOMING_TYPE:
                    dir = "INCOMING";
                    break;
                case CallLog.Calls.MISSED_TYPE:
                    dir = "MISSED";
                    break;
            }

            Call call = new Call(counter,phNumber,callType,dateString,callDuration,dir);
            Log.d("********",call.toString());
            callList.add(call);
            counter++;




        }
        managedCursor.close();

        Log.d("listingtostring",callList.toString());
        return callList;

    }

}