package com.example.scamsmart.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;

import com.example.scamsmart.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.BarLineChartBase;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class province_scams_activity extends AppCompatActivity {

    FirebaseFirestore fStore;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference postRef = db.collection("Posts");
    Integer intMunsterCount;
    Integer intLeinsterCount;
    Integer intUlsterCount;
    Integer intConnachtCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_province_scams_activity);
        intConnachtCount = 0;
        intLeinsterCount = 0;
        intMunsterCount = 0;
        intUlsterCount = 0;

        setTitle("ScamSMART - Province Stats");

        BarChart barChart = findViewById(R.id.bcProvinces);

        fStore = FirebaseFirestore.getInstance();

        CollectionReference provincesRef = db.collection("Posts");

        provincesRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()) {
                    for(DocumentSnapshot documentSnapshot : task.getResult()) {
                        String province;

                        //Adapted from https://stackoverflow.com/a/54838761
                        province = (String) documentSnapshot.get("Province").toString();

                        if(province.contains("Munster")) {
                            intMunsterCount++;
                        }
                        else if(province.contains("Leinster")) {
                            intLeinsterCount++;
                        }
                        else if(province.contains("Connacht")) {
                            intConnachtCount++;
                        }
                        else if(province.contains("Ulster")) {
                            intUlsterCount++;
                        }

                    }
                    setupBarChart(barChart,intLeinsterCount,intMunsterCount, intConnachtCount, intUlsterCount);

                }
            }
        });



    }


    private void setupBarChart(BarChart barChart, Integer LeinsterCount, Integer MunsterCount, Integer ConnachtCount, Integer UlsterCount) {
        //https://stackoverflow.com/a/56945823
        //https://github.com/PhilJay/MPAndroidChart/issues/978
        //https://stackoverflow.com/questions/57748668/center-x-axis-labels-in-center-of-points-in-android-mpandroidchart-barchart
        ArrayList<BarEntry> scams = new ArrayList<>();
        scams.add(new BarEntry(1,LeinsterCount));
        scams.add(new BarEntry(2,MunsterCount));
        scams.add(new BarEntry(3,ConnachtCount));
        scams.add(new BarEntry(4,UlsterCount));
        List<String> xAxisValues = new ArrayList<>(Arrays.asList("J", "Leinster", "Munster", "Connacht", "Ulster"));
        BarDataSet barDataSet = new BarDataSet(scams,"Number of Scams");
        barDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        barDataSet.setValueTextColor(Color.BLACK);
        barDataSet.setValueTextSize(18f);
        barChart.getDescription().setText("");
        BarData barData = new BarData(barDataSet);
        barChart.setFitBars(true);
        barChart.setData(barData);
        barData.setValueFormatter(new province_scams_activity.MyValueFormatter());
        calculateMinMax(barChart,5);
        barChart.animateY(2000);
        barChart.getXAxis().setValueFormatter(new com.github.mikephil.charting.formatter.IndexAxisValueFormatter(xAxisValues));
        barChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        YAxis rightYAxis = barChart.getAxisRight();
        rightYAxis.setEnabled(false);
        YAxis leftYAxis = barChart.getAxisLeft();
        leftYAxis.setValueFormatter(new province_scams_activity.MyValueFormatter());
        leftYAxis.setGranularity(1.0f);
        leftYAxis.setGranularityEnabled(true);
        XAxis xAxis = barChart.getXAxis();
        xAxis.setCenterAxisLabels(false);
        xAxis.setLabelCount(5);
    }

    //https://stackoverflow.com/a/44800697
    public class MyValueFormatter extends ValueFormatter {

        private DecimalFormat mFormat;

        public MyValueFormatter() {
            mFormat = new DecimalFormat("#");
        }

        @Override
        public String getFormattedValue(float value) {
            return mFormat.format(value);
        }
    }
    //https://stackoverflow.com/a/41788628
    private void calculateMinMax(BarLineChartBase chart, int labelCount) {
        float maxValue = chart.getData().getYMax();
        float minValue = chart.getData().getYMin();

        if ((maxValue - minValue) < labelCount) {
            float diff = labelCount - (maxValue - minValue);
            maxValue = maxValue + diff;
            chart.getAxisLeft().setAxisMaximum(maxValue);
            chart.getAxisLeft().setAxisMinimum(minValue);
        }
    }


}