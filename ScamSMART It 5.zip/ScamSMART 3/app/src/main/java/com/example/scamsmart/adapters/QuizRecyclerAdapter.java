package com.example.scamsmart.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.scamsmart.R;
import com.example.scamsmart.models.Question;
import com.example.scamsmart.ui.textinfo_activity;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class QuizRecyclerAdapter extends RecyclerView.Adapter<QuizRecyclerAdapter.MyViewHolder> {

    List<Question> questionList;
    Context context;

    public QuizRecyclerAdapter(List<Question> questionList, Context context) {
        this.questionList = questionList;
        this.context = context;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        Button btnInfo;
        TextView tvAnswer;
        EditText etExplanation;
        ImageView imQuestion;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            btnInfo = itemView.findViewById(R.id.btnReadMore);
            tvAnswer = itemView.findViewById(R.id.tvAnswer);
            etExplanation = itemView.findViewById(R.id.etQuestionExplanation);
            imQuestion = itemView.findViewById(R.id.imQuestionRecycler);


        }
    }

    @NonNull
    @NotNull
    @Override
    public QuizRecyclerAdapter.MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.onequestion,parent,false);
        QuizRecyclerAdapter.MyViewHolder holder = new QuizRecyclerAdapter.MyViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull QuizRecyclerAdapter.MyViewHolder holder, int position) {
        if(questionList.size() == 0) {

        }
        else {
            holder.tvAnswer.setText(questionList.get(position).getAnswer());
            Glide.with(context).load(questionList.get(position).getImageurl()).into(holder.imQuestion);
            holder.etExplanation.setText(questionList.get(position).getExplanation());
            holder.etExplanation.setEnabled(false);
            holder.btnInfo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(questionList.get(position).getCategory().equals("Text")) {
                        Intent startIntent = new Intent(context, textinfo_activity.class);
                        context.startActivity(startIntent);
                    }
                }
            });
        }

    }

    @Override
    public int getItemCount() {
        return questionList.size();
    }

}
